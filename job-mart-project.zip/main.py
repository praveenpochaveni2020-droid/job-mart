from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import sqlite3

app=FastAPI(title="Job Mart")
DB="job_mart.db"

def init():
    c=sqlite3.connect(DB)
    c.execute("CREATE TABLE IF NOT EXISTS jobs(id INTEGER PRIMARY KEY,title TEXT,company TEXT,location TEXT,category TEXT,salary TEXT)")
    if c.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]==0:
        c.executemany("INSERT INTO jobs(title,company,location,category,salary) VALUES(?,?,?,?,?)",[
        ("Delivery Executive","Job Mart Partner","Hyderabad","Delivery","₹15,000–₹25,000"),
        ("Sales Executive","Local Business","Hyderabad","Sales","₹18,000–₹30,000"),
        ("Computer Operator","Job Mart Partner","Warangal","Office","₹12,000–₹20,000")])
    c.commit(); c.close()
init()

@app.get("/health")
def health(): return {"status":"ok","service":"job-mart"}

@app.get("/",response_class=HTMLResponse)
def home():
    c=sqlite3.connect(DB); rows=c.execute("SELECT title,company,location,category,salary FROM jobs").fetchall(); c.close()
    cards="".join("<div class='card'><h3>"+str(r[0])+"</h3><b>"+str(r[1])+"</b><p>"+str(r[2])+" · "+str(r[4])+"</p><small>"+str(r[3])+"</small></div>" for r in rows)
    return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>Job Mart</title><style>body{font-family:Arial;margin:0;background:#f4f6f8;color:#17202a}header{background:#0867d5;color:white;padding:22px}main{max-width:900px;margin:auto;padding:16px}.brand{font-size:28px;font-weight:bold}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px}.card{background:white;padding:18px;border-radius:14px;box-shadow:0 2px 8px #0001}small{background:#e8f1ff;padding:5px 9px;border-radius:20px;color:#0757b5}</style></head><body><header><div class='brand'>Job Mart</div><div>Jobs, Recruitment and Services</div></header><main><h1>Find your next job</h1><div class='grid'>"+cards+"</div></main></body></html>"
